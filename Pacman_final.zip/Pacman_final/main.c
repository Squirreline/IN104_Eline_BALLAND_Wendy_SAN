#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ncurses.h>
#include <time.h>
#include "check.h"
#include "erase.h"
#include "construction.h"
#include "play.h"
#include "structures.h"
#include "fleche.h"

int main(){
  printf("essai")
}
